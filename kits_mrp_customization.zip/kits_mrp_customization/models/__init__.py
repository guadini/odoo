from . import product_product
from . import product_template
from . import stock_move_line
from . import stock_picking
from . import stock_warehouse
from . import stock_location_route
from . import stock_warehouse_orderpoint
from . import mrp_production
from . import stock_quant
from . import res_partner

# from . import kits_reel_allocate
# from . import kits_reel_allocate_line
